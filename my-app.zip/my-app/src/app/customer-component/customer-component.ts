import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer-service';

@Component({
  selector: 'app-customer-component',
  standalone: false,
  styleUrl: './customer-component.css',
  templateUrl: './customer-component.html',
})
export class CustomerComponent implements OnInit {
  customerGroups: any[] = [];

  constructor(private customerService: CustomerService) {}

  ngOnInit() {
    console.log('ngOnInit called');
    this.customerService.getCustomers().subscribe({
      next: data => {
        console.log('Data received:', data);
        this.customerGroups = data;
        console.log('customerGroups set:', this.customerGroups);
      },
      error: err => console.error('Error:', err)
    });
  }
}
